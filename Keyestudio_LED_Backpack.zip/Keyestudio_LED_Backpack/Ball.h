

class Ball{
  public: 
  int x;
  int y;
  int dirX;
  int dirY;

  void move();
  void bounceBackLeft();
  void bounceBackRight();
  void bounceUp();
  void bounceLeft();
  void bounceRight();
  void up();
  void down();
  };
